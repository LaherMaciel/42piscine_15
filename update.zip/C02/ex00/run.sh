clear
gcc -Wall -Wextra -Werror *.c && ./a.out
echo
echo
echo
norminette